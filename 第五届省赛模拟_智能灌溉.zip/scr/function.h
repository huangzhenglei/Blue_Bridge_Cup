#ifndef __FUNCTION_H
#define __FUNCTION_H

typedef enum
{
    GPIO_PIN_RESET = 0,
    GPIO_PIN_SET
}GPIO_PinState;

typedef enum
{
    No_Press = 0,
    s4 = 0x11,
    s5 = 0x12,
    s6 = 0x13,
    s7 = 0x14
}KEY_State;

typedef enum
{
    Automatic = 0,
    Manual,
    HumidityAdjust
}MODE_State;

typedef unsigned char u8;
typedef unsigned int u16;

void Delay3ms();
void Relay_Ctrl(u8 relay);
void Buzz_Ctrl(u8 buzz);
void Led_Ctrl(u8 led, GPIO_PinState state);
KEY_State Key_Scan();
KEY_State Key_Val();
void Display(u8 com, u8 num);
void Display_Time();
void Display_Humidity(u8 humidity);
void Display_Threshold(u8 threshold);

#endif
